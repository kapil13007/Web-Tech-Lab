import React from "react";
import AnimalList from "./components/AnimalList";
import "./App.css";

function App() {
  return <AnimalList />;
}

export default App;
