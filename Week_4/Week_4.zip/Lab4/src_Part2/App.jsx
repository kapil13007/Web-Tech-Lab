import React from "react";
import FoodTable from "./components/FoodTable";

function App() {
  return <FoodTable />;
}

export default App;


